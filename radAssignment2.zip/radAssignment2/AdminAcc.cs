﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace radAssignment2
{
    public class AdminAcc
    {
        public string username { get; set; }

        public string password { get; set; }
    }
}
