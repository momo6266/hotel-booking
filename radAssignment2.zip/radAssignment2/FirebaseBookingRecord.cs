﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace radAssignment2
{
    public class FirebaseBookingRecord
    {
        public string Key { get; set; }
        public BookingRecord BookingData { get; set; }
    }
}
