﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace radAssignment2
{
    public class FeedbackModel
    {
        public string NameText { get; set; }
        public string FeedbackText { get; set; }
        public DateTime Timestamp { get; set; }
    }
}
