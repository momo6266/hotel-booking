﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace radAssignment2
{
    public class RoomTypeItem
    {
        public string Key { get; set; }
        public string RoomType { get; set; }
        public RoomInfo RoomInfo { get; set; }
    }
}
