﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace radAssignment2
{
    public class RoomInfo
    {
        public string RoomType { get; set; }
        public int Price { get; set; }
        public int Limit { get; set; }
    }
}
