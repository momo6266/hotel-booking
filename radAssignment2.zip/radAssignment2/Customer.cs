﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace radAssignment2
{
    public class Customer
    {
        public string FirebaseKey { get; set; }
        public string CCity { get; set; }
        public int CPost { get; set; }
        public string CState { get; set; }
        public string CStreet { get; set; }
        public string CEmail { get; set; }
        public string CName { get; set; }
        public string CNickname { get; set; }
        public int CPhone { get; set; }
        public DateTime CDob {get; set;}
    }
}
